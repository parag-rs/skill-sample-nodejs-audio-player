package io.swagger.api;

import io.swagger.model.Response;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2023-05-11T07:41:39.474Z")

@Controller
public class SendApiController implements SendApi {

    private static final Logger log = LoggerFactory.getLogger(SendApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public SendApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<Response> sendPost(@ApiParam(value = "The unique identifier to the request", required=true) @RequestParam(value="tid", required=true)  String tid,@ApiParam(value = "A Signed JWT that must be send back to the AccessManagement callback to trust the response", required=true) @RequestParam(value="state", required=true)  String state,@ApiParam(value = "The user identifier", required=true) @RequestParam(value="subject", required=true)  String subject,@ApiParam(value = "The scope of the access request as described by Section 3.3 of the OAuth 2.0 Authorization Framework (may appear multiple time)", required=true) @RequestParam(value="scope", required=true)  String scope,@ApiParam(value = "The expected response time of the end-user (in second)", required=true) @RequestParam(value="expire", required=true)  Integer expire,@ApiParam(value = "Requested Authentication Context Class Reference value (may appear multiple time)", required=true) @RequestParam(value="acr", required=true)  String acr,@ApiParam(value = "A human-readable identifier or message intended to be displayed on both the consumption device and the authentication device to interlock them together for the transaction by way of a visual cue for the end-user", required=true) @RequestParam(value="message", required=true)  String message) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<Response>(objectMapper.readValue("{\"empty\": false}", Response.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<Response>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<Response>(HttpStatus.NOT_IMPLEMENTED);
    }

}
