package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Response
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2023-05-11T07:41:39.474Z")


public class Response   {
  @JsonProperty("tid")
  private String tid = null;

  @JsonProperty("state")
  private String state = null;

  @JsonProperty("data")
  private Object data = null;

  public Response tid(String tid) {
    this.tid = tid;
    return this;
  }

  /**
   * REQUIRED. The unique identifier provided as request parameter.
   * @return tid
  **/
  @ApiModelProperty(value = "REQUIRED. The unique identifier provided as request parameter.")


  public String getTid() {
    return tid;
  }

  public void setTid(String tid) {
    this.tid = tid;
  }

  public Response state(String state) {
    this.state = state;
    return this;
  }

  /**
   * REQUIRED. The state provided as request parameter.
   * @return state
  **/
  @ApiModelProperty(value = "REQUIRED. The state provided as request parameter.")


  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public Response data(Object data) {
    this.data = data;
    return this;
  }

  /**
   * OPTIONAL. A map of key/value pairs to provide additional information
   * @return data
  **/
  @ApiModelProperty(value = "OPTIONAL. A map of key/value pairs to provide additional information")


  public Object getData() {
    return data;
  }

  public void setData(Object data) {
    this.data = data;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Response response = (Response) o;
    return Objects.equals(this.tid, response.tid) &&
        Objects.equals(this.state, response.state) &&
        Objects.equals(this.data, response.data);
  }

  @Override
  public int hashCode() {
    return Objects.hash(tid, state, data);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Response {\n");
    
    sb.append("    tid: ").append(toIndentedString(tid)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    data: ").append(toIndentedString(data)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

